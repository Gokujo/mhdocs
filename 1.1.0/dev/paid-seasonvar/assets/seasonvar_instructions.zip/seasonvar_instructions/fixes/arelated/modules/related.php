<?php
/*
=====================================================
Related - Вывод похожих новостей
-----------------------------------------------------
Автор : Gameer
-----------------------------------------------------
Site : http://gameer.name/
-----------------------------------------------------
Copyright (c) 2016 Gameer
=====================================================
Данный код защищен авторскими правами
*/
if( ! defined( 'DATALIFEENGINE' ) ) return;

$newsid = isset($newsid) ? intval($newsid) : false;
$tep = isset($tep) ? $db->safesql(trim(strip_tags(stripslashes($tep)))) : false;
$counts = isset($counts) ? intval($counts) : 5;

if(!$newsid) return;

$allow_cache = ($config['version_id'] >= '10.2') ? $config['allow_cache'] == '1' : $config['allow_cache'] == "yes";

$is_change = false;
if (!$allow_cache) // если кэш не включен включаем принудительно
{
	if ($config['version_id'] >= '10.2')
		$config['allow_cache'] = '1';
	else 
		$config['allow_cache'] = "yes";
	$is_change = true;
}

$show = dle_cache( "news_nrelated_",  $newsid, false);
if ($show !== false) 
{
	echo $show;
	return;
}
global $row;

if(!$row["related_ids"])
{
	if ($config['allow_multi_category'])
		$where_category = "category REGEXP '[[:<:]](" . $category_id . ")[[:>:]]' AND ";
	else
		$where_category = "category IN ('" . $category_id . "') AND ";
	
	$arr_idnews = array();
	
	$sql = $db->query( "SELECT id FROM " . PREFIX . "_post WHERE {$where_category} id !='{$newsid}' AND approve=1 LIMIT " . $counts );
	while( $row = $db->get_row($sql) )
		if($row["id"]) $arr_idnews[] = $row["id"];
	
	$tpl = new dle_template();
	$tpl->dir = TEMPLATE_DIR;
	if($tep)
		$tpl->load_template( $tep . '.tpl' );
	else
		$tpl->load_template( 'relatedn.tpl' );
	$tpl2 = new dle_template();
	$tpl2->dir = TEMPLATE_DIR;
	if($tep)
		$tpl2->load_template( 'rentmp_' . $tep . '.tpl' );
	else
		$tpl2->load_template( 'rentmp.tpl' );
	if(count($arr_idnews))
	{
		$related_ids = implode(",", $arr_idnews);
		$db->query("UPDATE " . PREFIX . "_post_extras SET related_ids='{$related_ids}' WHERE news_id='{$newsid}'");
		$where = "id IN ('" . implode("','", $arr_idnews) . "')";
		$sql_select = "SELECT p.id, p.autor, p.date, p.short_story, CHAR_LENGTH(p.full_story) as full_story, p.xfields, p.title, p.category, p.alt_name, p.comm_num, p.allow_comm, p.fixed, p.tags, e.news_read, e.allow_rate, e.rating, e.vote_num, e.votes, e.view_edit, e.editdate, e.editor, e.reason FROM " . PREFIX . "_post p LEFT JOIN " . PREFIX . "_post_extras e ON (p.id=e.news_id) WHERE {$where} AND approve='1' ORDER BY date DESC LIMIT " . $counts;
		$sql_result = $db->query( $sql_select );

		include (ENGINE_DIR . '/modules/show.custom.php');

		if( $config['files_allow'] ) if( strpos( $tpl->result['content'], "[attachment=" ) !== false )
			$tpl->result['content'] = show_attach( $tpl->result['content'], $attachments );
		$tpl2->set('{related}', $tpl->result['content']);
		$tpl2->copy_template = preg_replace( "'\\[related\\](.*?)\\[/related\\]'is", "\\1", $tpl2->copy_template);
		$tpl2->copy_template = preg_replace( "'\\[not-related\\](.*?)\\[/not-related\\]'is", "", $tpl2->copy_template);
		$tpl2->compile("related");
		$tpl2->clear();
	}
	else
	{
		$tpl2->copy_template = preg_replace( "'\\[related\\](.*?)\\[/related\\]'is", "", $tpl2->copy_template);
		$tpl2->copy_template = preg_replace( "'\\[not-related\\](.*?)\\[/not-related\\]'is", "\\1", $tpl2->copy_template);
		$tpl2->compile("related");
		$tpl2->clear();
	}
}
else
{
	$tpl = new dle_template();
	$tpl->dir = TEMPLATE_DIR;
	if($tep)
		$tpl->load_template( $tep . '.tpl' );
	else
		$tpl->load_template( 'relatedn.tpl' );
	$tpl2 = new dle_template();
	$tpl2->dir = TEMPLATE_DIR;
	if($tep)
		$tpl2->load_template( 'rentmp_' . $tep . '.tpl' );
	else
		$tpl2->load_template( 'rentmp.tpl' );
	$where = "id IN ('" . str_replace(',', "','", $row["related_ids"]) . "')";
	$sql_select = "SELECT p.id, p.autor, p.date, p.short_story, CHAR_LENGTH(p.full_story) as full_story, p.xfields, p.title, p.category, p.alt_name, p.comm_num, p.allow_comm, p.fixed, p.tags, e.news_read, e.allow_rate, e.rating, e.vote_num, e.votes, e.view_edit, e.editdate, e.editor, e.reason FROM " . PREFIX . "_post p LEFT JOIN " . PREFIX . "_post_extras e ON (p.id=e.news_id) WHERE {$where} AND approve='1' ORDER BY date DESC LIMIT " . $counts;
	$sql_result = $db->query( $sql_select );

	include (ENGINE_DIR . '/modules/show.custom.php');

	if( $config['files_allow'] ) if( strpos( $tpl->result['content'], "[attachment=" ) !== false )
		$tpl->result['content'] = show_attach( $tpl->result['content'], $attachments );
	$tpl2->set('{related}', $tpl->result['content']);
	$tpl2->copy_template = preg_replace( "'\\[related\\](.*?)\\[/related\\]'is", "\\1", $tpl2->copy_template);
	$tpl2->copy_template = preg_replace( "'\\[not-related\\](.*?)\\[/not-related\\]'is", "", $tpl2->copy_template);
	$tpl2->compile("related");
	$tpl2->clear();
}
create_cache( "news_nrelated_", $tpl2->result['related'], $news_id, false);
if ($is_change)
	$config['allow_cache'] = false; //выключаем кэш принудительно (возвращаем назад)
echo $tpl2->result['related'];
?>